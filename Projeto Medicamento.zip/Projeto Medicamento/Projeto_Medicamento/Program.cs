﻿using System;

namespace Projeto_Medicamento
{
    class Program
    {
        static Medicamento medicamento;
        static Medicamentos medicamentos;

        static void Main(string[] args)
        {
            medicamentos = new Medicamentos();
            int opcao = 1;
            do
            {
                Console.Clear();
                Console.WriteLine("");
                Console.WriteLine("0 - Finalizar processo");
                Console.WriteLine("1 - Cadastrar medicamento");
                Console.WriteLine("2 - Consultar medicamento (sintético)");
                Console.WriteLine("3 - Consultar medicamento (analítico)");
                Console.WriteLine("4 - Comprar medicamento (cadastrar lote)");
                Console.WriteLine("5 - Vender medicamento (abater do lote mais antigo)");
                Console.WriteLine("6 - Listar medicamentos (informar dados sintéticos)");
                Console.WriteLine("Opção: ");
                    opcao = int.Parse(Console.ReadLine());
                    if (opcao > 6) {
                        Console.Clear();
                        Console.WriteLine("Erro, tente denovo:");
                        Console.ReadKey();
                    }
                switch (opcao)
                {
                    case 1: cadastrarMedicamento(); break;
                    case 2: consultaSintetico(); break;
                    case 3: consultaAnalitico(); break;
                    case 4: comprarMedicamento(); break;
                    case 5: venderMedicamento(); break;
                    case 6: listarMedicamentos(); break;
                }
            } while (opcao != 0);
        }

        static public void cadastrarMedicamento() {
            int idMed, idLote, qtde;
            string nome, laboratorio;
            DateTime venc;
            Console.Clear();
            Console.WriteLine("Cadastro do Medicamento");
            
            Console.WriteLine("Id: ");idMed = entraInt();
            Console.WriteLine("Nome: ");nome = Console.ReadLine();
            Console.WriteLine("Laboratório: ");laboratorio = Console.ReadLine();
            Console.WriteLine("Id do Lote: ");idLote = entraInt();
            Console.WriteLine("Quantidade: ");qtde = entraInt();
            Console.WriteLine("Data de Vencimento: ");
            venc = entraData();
            if (venc != DateTime.MinValue)
            {
                medicamento = new Medicamento(idMed, nome, laboratorio);
                medicamentos.adicionar(medicamento);
                medicamento.comprar(new Lote(idLote, qtde, venc));
                Console.Clear();
                Console.WriteLine("Medicamento adicionado com sucesso.");
            }
            }

        static public void consultaSintetico(){
            Console.Clear();
            Console.WriteLine("Consulta Sintética");
            Console.WriteLine("Digite o ID do medicamento. ");
            medicamento = new Medicamento(entraInt());
            medicamento = medicamentos.pesquisar(medicamento);
            if (medicamento != null)
            {
                Console.Clear();
                Console.WriteLine("Resultado da Consulta Analitica");
                Console.WriteLine(medicamento.toString());
                Console.ReadKey();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Medicamento não encontrado.");
                Console.ReadKey();
            }
        }

        static public void consultaAnalitico(){
            Console.Clear();
            Console.WriteLine("Consulta Analitica");
            Console.WriteLine("Digite o ID do medicamento.");
            medicamento = new Medicamento(entraInt());
            medicamento = medicamentos.pesquisar(medicamento);
            if (medicamento != null)
            {
                Console.Clear();
                Console.WriteLine("Resultado da Consulta Analitica");
                Console.WriteLine(medicamento.toString());
                int cont = 10;
                foreach (Lote lote in medicamento.Lotes)
                {
                    Console.SetCursorPosition(1, cont); Console.WriteLine(lote.toString());
                    cont = cont+1;
                }
                Console.ReadKey();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Medicamento não encontrado!");
                Console.ReadKey();
            }
        }

        static public void comprarMedicamento() {
            int idLote, qtde;
            DateTime venc;
            Console.Clear();
            Console.WriteLine("Compra de Medicamento");
            Console.WriteLine("Digite o ID do medicamento.");
            medicamento = new Medicamento(entraInt());
            medicamento = medicamentos.pesquisar(medicamento);
            if (medicamento != null)
            {
                Console.WriteLine("Id do Lote: "); idLote = entraInt();
                Console.WriteLine("Quantidade: "); qtde = entraInt();
                Console.WriteLine("Data de Vencimento: ");
                venc = entraData();
                if (venc != DateTime.MinValue)
                {
                    medicamento.comprar(new Lote(idLote, qtde, venc));
                    Console.Clear();
                    Console.WriteLine("Medicamento adicionado com sucesso.");
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Medicamento não encontrado.");
                Console.ReadKey();
            }
        }

        static public void venderMedicamento() {
            int qtde;
            Console.Clear();
            Console.WriteLine("Venda de Medicamento");
            Console.WriteLine("Digite o ID do medicamento.");
            medicamento = new Medicamento(entraInt());
            medicamento = medicamentos.pesquisar(medicamento);
            if (medicamento != null)
            {
                Console.WriteLine("Quantidade: ");
                qtde = entraInt();
                if (medicamento.vender(qtde))
                {
                    {
                        Console.Clear();
                        Console.WriteLine("Medicamento vendido!");
                        Console.ReadKey();
                    }
                    if (medicamentos.deletar(medicamento))
                    {
                        Console.Clear();
                        Console.WriteLine("Lote de medicamento zerado...");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Quantidade insuficiente");
                        Console.WriteLine("Resta: " + medicamento.qtdeDisponivel() + " no estoque..."); 
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Quantidade insuficiente");
                    Console.ReadKey();
                }
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Medicamento não encontrado!");
                Console.ReadKey();
            }
        }

        static public void listarMedicamentos() {
            Console.Clear();
            Console.WriteLine("Lista de todos os medicamentos");
            Console.WriteLine("");
            if (medicamentos.ListaMedicamentos.Count != 0)
            {
                int cont = 10;
                foreach (Medicamento medicamento in medicamentos.ListaMedicamentos)
                {
                    Console.WriteLine(medicamento.toString());
                    cont = cont + 1;
                }
                Console.ReadKey();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Estoque vazio");
                Console.ReadKey();
            }
        }
        static public int entraInt() {
            int num=0;
            while (num == 0) {
                try { num = int.Parse(Console.ReadLine()); }
                catch {Console.WriteLine("Digite um número válido: "); num = 0; }
            }
            return num;
        }

        static public DateTime entraData()
        {
            DateTime data;
            int dia, mes, ano;Console.WriteLine("Dia: ");
            dia = entraInt();Console.WriteLine("Mês: ");
            mes = entraInt();Console.WriteLine("Ano: ");
            ano = entraInt();
            try
            {
                data = new DateTime(ano, mes, dia);
                if (data.Ticks - DateTime.Now.Ticks > 0)
                    return data;
                else
                {
                    Console.Clear();
                    Console.WriteLine("Medicamento vencido.");
                    Console.ReadKey();
                    return DateTime.MinValue;
                }
            }
            catch
            {
                Console.Clear();
                Console.WriteLine("Data inválida!");
                Console.ReadKey();
                return entraData();
            }
        }
    }
}
